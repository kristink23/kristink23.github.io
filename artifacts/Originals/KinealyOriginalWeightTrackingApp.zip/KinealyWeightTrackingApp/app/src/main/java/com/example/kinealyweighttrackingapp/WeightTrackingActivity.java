package com.example.kinealyweighttrackingapp;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class WeightTrackingActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private TableLayout tableLayout;
    private EditText dateInput, weightInput;
    private Button addEntryButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_tracking);

        // Initialize Database Helper
        dbHelper = new DatabaseHelper(this);

        // Initialize UI Elements
        tableLayout = findViewById(R.id.weightLog);
        dateInput = findViewById(R.id.dateInput);
        weightInput = findViewById(R.id.weightInput);
        addEntryButton = findViewById(R.id.addEntry);

        // Load Existing Weight Entries
        loadWeightEntries();

        // Handle Adding New Entries
        addEntryButton.setOnClickListener(v -> addNewEntry());
    }

    // Function to Load Weight Data from Database
    private void loadWeightEntries() {
        tableLayout.removeViews(1, Math.max(0, tableLayout.getChildCount() - 1)); // Keep table headers

        Cursor cursor = dbHelper.getAllWeightEntries();
        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String date = cursor.getString(1);
            String weight = cursor.getString(2);
            addTableRow(id, date, weight);
        }
        cursor.close();
    }

    // Function to Add New Weight Entry
    private void addNewEntry() {
        String date = dateInput.getText().toString().trim();
        String weight = weightInput.getText().toString().trim();

        if (date.isEmpty() || weight.isEmpty()) {
            Toast.makeText(this, "Please enter a date and weight.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (dbHelper.addWeightEntry(date, weight)) {
            Toast.makeText(this, "Entry Added!", Toast.LENGTH_SHORT).show();
            loadWeightEntries(); // Refresh Table
            dateInput.setText(""); // Clear Input
            weightInput.setText("");
        } else {
            Toast.makeText(this, "Error adding entry", Toast.LENGTH_SHORT).show();
        }
    }

    // Function to Dynamically Add Table Row
    private void addTableRow(int id, String date, String weight) {
        TableRow row = new TableRow(this);

        // Date Column
        TextView dateText = new TextView(this);
        dateText.setText(date);
        dateText.setPadding(10, 10, 10, 10);
        dateText.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

        // Weight Column
        TextView weightText = new TextView(this);
        weightText.setText(weight);
        weightText.setPadding(10, 10, 10, 10);
        weightText.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

        // Delete Button
        Button deleteButton = new Button(this);
        deleteButton.setText("Delete");
        deleteButton.setOnClickListener(v -> {
            dbHelper.deleteWeightEntry(id);
            loadWeightEntries(); // Refresh Table
        });

        // Add to TableRow
        row.addView(dateText);
        row.addView(weightText);
        row.addView(deleteButton);

        // Add Row to TableLayout
        tableLayout.addView(row);
    }
}