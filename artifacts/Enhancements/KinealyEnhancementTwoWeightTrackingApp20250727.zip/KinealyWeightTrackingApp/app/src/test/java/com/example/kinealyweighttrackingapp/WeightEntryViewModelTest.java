package com.example.kinealyweighttrackingapp;

import static org.mockito.Mockito.*;
import static org.junit.Assert.assertEquals;

import androidx.arch.core.executor.testing.InstantTaskExecutorRule;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.MockitoAnnotations;

import android.app.Application;

import java.util.Arrays;
import java.util.function.Consumer;

public class WeightEntryViewModelTest {

    @Rule
    public InstantTaskExecutorRule rule = new InstantTaskExecutorRule(); // Required for LiveData

    private DatabaseHelper dbMock;
    private WeightEntryViewModel viewModel;
    private Application mockApp;

    @Before
    public void setup() {
        MockitoAnnotations.openMocks(this);
        dbMock = mock(DatabaseHelper.class);
        mockApp = mock(Application.class);
        viewModel = new WeightEntryViewModel(mockApp, dbMock);
    }

    @Test
    public void addWeightEntry_valid_callsLoadEntries() {
        // Arrange
        String date = "2023-12-01";
        String weight = "150";
        when(dbMock.addWeightEntry(date, weight)).thenReturn(true);
        when(dbMock.getAllWeightEntries()).thenReturn(mock(android.database.Cursor.class));

        @SuppressWarnings("unchecked")
        Consumer<Boolean> callback = mock(Consumer.class);

        // Act
        viewModel.addWeightEntry(date, weight, callback);

        // Wait for async executor
        try { Thread.sleep(200); } catch (InterruptedException ignored) {}

        // Assert
        verify(dbMock).addWeightEntry(date, weight);
        verify(dbMock, atLeastOnce()).getAllWeightEntries();
        verify(callback).accept(true);
    }

    // ---------- Tests for calculateWeightTrend() ----------

    @Test
    public void calculateWeightTrend_gainingWeight() {
        viewModel.getWeightEntries().setValue(Arrays.asList(
                new WeightEntry(1, "2023-12-01", "150"),
                new WeightEntry(2, "2023-12-02", "152"),
                new WeightEntry(3, "2023-12-03", "155")
        ));

        String result = viewModel.calculateWeightTrend();
        assertEquals("You are gaining weight.", result);
    }

    @Test
    public void calculateWeightTrend_losingWeight() {
        viewModel.getWeightEntries().setValue(Arrays.asList(
                new WeightEntry(1, "2023-12-01", "160"),
                new WeightEntry(2, "2023-12-02", "158"),
                new WeightEntry(3, "2023-12-03", "155")
        ));

        String result = viewModel.calculateWeightTrend();
        assertEquals("You are losing weight.", result);
    }

    @Test
    public void calculateWeightTrend_stableWeight() {
        viewModel.getWeightEntries().setValue(Arrays.asList(
                new WeightEntry(1, "2023-12-01", "150"),
                new WeightEntry(2, "2023-12-02", "150"),
                new WeightEntry(3, "2023-12-03", "150")
        ));

        String result = viewModel.calculateWeightTrend();
        assertEquals("Your weight is stable.", result);
    }

    @Test
    public void calculateWeightTrend_notEnoughData() {
        viewModel.getWeightEntries().setValue(Arrays.asList(
                new WeightEntry(1, "2023-12-01", "150")
        ));

        String result = viewModel.calculateWeightTrend();
        assertEquals("Not enough data to calculate trend.", result);
    }
}