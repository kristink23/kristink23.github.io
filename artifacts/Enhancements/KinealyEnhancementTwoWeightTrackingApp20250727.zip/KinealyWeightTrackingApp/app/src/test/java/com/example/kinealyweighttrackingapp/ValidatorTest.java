package com.example.kinealyweighttrackingapp;

import org.junit.Test;
import static org.junit.Assert.*;

public class ValidatorTest {

    @Test
    public void testValidDate() {
        assertTrue(Validator.isValidDate("2023-12-01"));
        assertFalse(Validator.isValidDate("12/01/2023"));
        assertFalse(Validator.isValidDate("2023/12/01"));
    }

    @Test
    public void testValidWeight() {
        assertTrue(Validator.isValidWeight("150"));
        assertFalse(Validator.isValidWeight("-10"));
        assertFalse(Validator.isValidWeight("abc"));
    }
}