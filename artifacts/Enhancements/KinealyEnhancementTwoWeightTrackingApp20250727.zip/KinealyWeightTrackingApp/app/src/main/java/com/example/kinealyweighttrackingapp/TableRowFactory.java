package com.example.kinealyweighttrackingapp;

import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.TableRow;
import android.widget.TextView;

public class TableRowFactory {

    public static TableRow createRow(Context context, WeightEntry entry, WeightEntryViewModel viewModel) {
        TableRow row = new TableRow(context);

        // Date Column
        TextView dateText = new TextView(context);
        dateText.setText(entry.getDate());
        dateText.setPadding(10, 10, 10, 10);
        dateText.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

        // Weight Column
        TextView weightText = new TextView(context);
        weightText.setText(entry.getWeight());
        weightText.setPadding(10, 10, 10, 10);
        weightText.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

        // Delete Button
        Button deleteButton = new Button(context);
        deleteButton.setText(R.string.delete);
        deleteButton.setOnClickListener(v -> viewModel.deleteWeightEntry(entry.getId()));

        // Add views to TableRow
        row.addView(dateText);
        row.addView(weightText);
        row.addView(deleteButton);

        return row;
    }
}
