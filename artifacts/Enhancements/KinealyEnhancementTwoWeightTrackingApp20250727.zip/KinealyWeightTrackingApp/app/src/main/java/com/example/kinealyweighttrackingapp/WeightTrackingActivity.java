package com.example.kinealyweighttrackingapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView; // Used for displaying the trend message
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class WeightTrackingActivity extends AppCompatActivity {

    // Input fields for date and weight
    private EditText dateInput, weightInput;
    private Button addEntry;          // Button for adding a new entry
    private TextView trendMessage;    // TextView to show weight trend message

    // ViewModel and Adapter for data handling and UI display
    private WeightEntryViewModel viewModel;
    private WeightEntryAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_tracking);

        // Initialize all views by linking them to the layout elements
        dateInput = findViewById(R.id.dateInput);
        weightInput = findViewById(R.id.weightInput);
        addEntry = findViewById(R.id.addEntry);
        trendMessage = findViewById(R.id.trendMessage); // TextView added to show trend results
        RecyclerView recyclerView = findViewById(R.id.recyclerView);

        // Set up RecyclerView with the adapter and layout manager
        adapter = new WeightEntryAdapter(
                this,
                new ArrayList<>(),
                entry -> viewModel.deleteWeightEntry(entry.getId()) // Delete button click listener
        );
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        // Initialize the ViewModel (data source + business logic)
        viewModel = new ViewModelProvider(this).get(WeightEntryViewModel.class);

        // Observe LiveData (list of weight entries) and update the UI automatically
        viewModel.getWeightEntries().observe(this, entries -> {
            // Update the list in the RecyclerView
            adapter.updateEntries(entries);

            // Recalculate the weight trend every time the data changes and display it
            String trend = viewModel.calculateWeightTrend();
            trendMessage.setText(trend);
        });

        // Set up the logic for the Add Entry button
        addEntry.setOnClickListener(v -> {
            String date = dateInput.getText().toString().trim();
            String weight = weightInput.getText().toString().trim();

            // Validate date format (YYYY-MM-DD)
            if (!Validator.isValidDate(date)) {
                Toast.makeText(this, "Invalid date format (expected YYYY-MM-DD)", Toast.LENGTH_SHORT).show();
                return;
            }

            // Validate weight (must be a positive number less than 1000)
            if (!Validator.isValidWeight(weight)) {
                Toast.makeText(this, "Invalid weight (positive number < 1000)", Toast.LENGTH_SHORT).show();
                return;
            }

            // Add the weight entry via the ViewModel
            viewModel.addWeightEntry(date, weight, success -> {
                // runOnUiThread is needed because addWeightEntry runs asynchronously
                runOnUiThread(() -> {
                    if (Boolean.TRUE.equals(success)) {
                        Toast.makeText(this, "Entry added!", Toast.LENGTH_SHORT).show();
                        // Clear inputs on success
                        dateInput.setText("");
                        weightInput.setText("");
                    } else {
                        Toast.makeText(this, "Failed to add entry", Toast.LENGTH_SHORT).show();
                    }
                });
            });
        });
    }
}