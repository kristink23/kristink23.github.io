package com.example.kinealyweighttrackingapp;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SMSPermissionActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 1;
    private Button allowButton, denyButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        allowButton = findViewById(R.id.allowButton);
        denyButton = findViewById(R.id.denyButton);

        // Save that the user has checked SMS permission (so they don't see this screen again)
        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        prefs.edit().putBoolean("hasCheckedSMS", true).apply();

        // Allow Button Click
        allowButton.setOnClickListener(v -> requestSMSPermission());

        // Deny Button Click
        denyButton.setOnClickListener(v -> {
            openWeightTrackingActivity(); // Go to Weight Tracking even if user denies SMS
        });
    }

    // Request SMS Permission
    private void requestSMSPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        } else {
            openWeightTrackingActivity(); // If already granted, continue
        }
    }

    // Handle Permission Result
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            openWeightTrackingActivity(); // Continue to Weight Tracking, no matter the choice
        }
    }

    // Open Weight Tracking Activity
    private void openWeightTrackingActivity() {
        Intent intent = new Intent(SMSPermissionActivity.this, WeightTrackingActivity.class);
        startActivity(intent);
        finish(); // Prevent returning to this screen
    }
}