package com.example.kinealyweighttrackingapp;

public class Validator {

    public static boolean isValidDate(String date) {
        return date.matches("\\d{4}-\\d{2}-\\d{2}"); // basic YYYY-MM-DD format
    }

    public static boolean isValidWeight(String weight) {
        try {
            float w = Float.parseFloat(weight);
            return w > 0 && w < 1000;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    // New method to support validation logic in Activity
    public static String validateWeightEntry(String date, String weight) {
        if (date.isEmpty() || weight.isEmpty()) {
            return "Date and weight cannot be empty.";
        }
        if (!isValidDate(date)) {
            return "Invalid date format. Use YYYY-MM-DD.";
        }
        if (!isValidWeight(weight)) {
            return "Invalid weight. Enter a number between 0 and 1000.";
        }
        return null; // null means valid
    }
}
