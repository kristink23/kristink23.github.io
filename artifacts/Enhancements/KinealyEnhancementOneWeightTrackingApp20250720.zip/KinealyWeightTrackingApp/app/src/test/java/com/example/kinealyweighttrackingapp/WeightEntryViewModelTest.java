package com.example.kinealyweighttrackingapp;

import static org.mockito.Mockito.*;

import androidx.arch.core.executor.testing.InstantTaskExecutorRule;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.MockitoAnnotations;

import android.app.Application;

import java.util.function.Consumer;

public class WeightEntryViewModelTest {

    @Rule
    public InstantTaskExecutorRule rule = new InstantTaskExecutorRule(); // Required for LiveData

    private DatabaseHelper dbMock;
    private WeightEntryViewModel viewModel;
    private Application mockApp;

    @Before
    public void setup() {
        MockitoAnnotations.openMocks(this);
        dbMock = mock(DatabaseHelper.class);
        mockApp = mock(Application.class);
        viewModel = new WeightEntryViewModel(mockApp, dbMock);
    }

    @Test
    public void addWeightEntry_valid_callsLoadEntries() {
        // Arrange
        String date = "2023-12-01";
        String weight = "150";
        when(dbMock.addWeightEntry(date, weight)).thenReturn(true);
        when(dbMock.getAllWeightEntries()).thenReturn(mock(android.database.Cursor.class));

        @SuppressWarnings("unchecked")
        Consumer<Boolean> callback = mock(Consumer.class);

        // Act
        viewModel.addWeightEntry(date, weight, callback);

        try { Thread.sleep(200); } catch (InterruptedException ignored) {}

        // Assert
        verify(dbMock).addWeightEntry(date, weight);
        verify(dbMock, atLeastOnce()).getAllWeightEntries();
        verify(callback).accept(true);
    }
}

