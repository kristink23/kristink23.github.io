package com.example.kinealyweighttrackingapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class WeightTrackingActivity extends AppCompatActivity {

    private EditText dateInput, weightInput;
    private Button addEntry;
    private WeightEntryViewModel viewModel;
    private WeightEntryAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_tracking);

        // Initialize views
        dateInput = findViewById(R.id.dateInput);
        weightInput = findViewById(R.id.weightInput);
        addEntry = findViewById(R.id.addEntry);
        RecyclerView recyclerView = findViewById(R.id.recyclerView);

        // Set up RecyclerView
        adapter = new WeightEntryAdapter(
                this,
                new ArrayList<>(),
                entry -> viewModel.deleteWeightEntry(entry.getId())
        );
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        // Initialize ViewModel
        viewModel = new ViewModelProvider(this).get(WeightEntryViewModel.class);

        // Observe LiveData for updates
        viewModel.getWeightEntries().observe(this, entries -> {
            adapter.updateEntries(entries);
        });

        // Add entry button logic
        addEntry.setOnClickListener(v -> {
            String date = dateInput.getText().toString().trim();
            String weight = weightInput.getText().toString().trim();

            if (!Validator.isValidDate(date)) {
                Toast.makeText(this, "Invalid date format (expected YYYY-MM-DD)", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!Validator.isValidWeight(weight)) {
                Toast.makeText(this, "Invalid weight (positive number < 1000)", Toast.LENGTH_SHORT).show();
                return;
            }

            viewModel.addWeightEntry(date, weight, success -> {
                runOnUiThread(() -> {
                    if (Boolean.TRUE.equals(success)) {
                        Toast.makeText(this, "Entry added!", Toast.LENGTH_SHORT).show();
                        dateInput.setText("");
                        weightInput.setText("");
                    } else {
                        Toast.makeText(this, "Failed to add entry", Toast.LENGTH_SHORT).show();
                    }
                });
            });
        });
    }
}