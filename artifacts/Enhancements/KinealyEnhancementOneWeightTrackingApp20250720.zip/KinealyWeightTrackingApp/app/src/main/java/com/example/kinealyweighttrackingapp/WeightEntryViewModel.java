package com.example.kinealyweighttrackingapp;

import android.app.Application;
import android.database.Cursor;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.MutableLiveData;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

public class WeightEntryViewModel extends AndroidViewModel {

    // Database helper for performing SQLite operations
    private final DatabaseHelper dbHelper;

    // LiveData to hold and observe the list of weight entries
    private final MutableLiveData<List<WeightEntry>> weightEntries;

    // Executor for running database tasks on a background thread
    private final ExecutorService executor;

    // Constructor used in the actual app – initializes with a real DatabaseHelper
    public WeightEntryViewModel(@NonNull Application application) {
        super(application);
        this.dbHelper = new DatabaseHelper(application);
        this.weightEntries = new MutableLiveData<>();
        this.executor = Executors.newSingleThreadExecutor();
        loadEntries(); // Load initial data
    }

    // Alternate constructor for unit testing – lets us pass in a mock DatabaseHelper
    public WeightEntryViewModel(@NonNull Application application, @NonNull DatabaseHelper dbHelper) {
        super(application);
        this.dbHelper = dbHelper;
        this.weightEntries = new MutableLiveData<>();
        this.executor = Executors.newSingleThreadExecutor();
        loadEntries(); // Load mock/test data
    }

    // Public method to expose LiveData for observing the list of entries
    public MutableLiveData<List<WeightEntry>> getWeightEntries() {
        return weightEntries;
    }

    // Adds a new entry to the database and updates the LiveData list
    // Accepts a callback (like for showing success/failure in the UI)
    public void addWeightEntry(String date, String weight, Consumer<Boolean> callback) {
        executor.execute(() -> {
            boolean success = dbHelper.addWeightEntry(date, weight);
            if (success) {
                loadEntries(); // Refresh list if added successfully
            }
            if (callback != null) {
                callback.accept(success); // Pass result back
            }
        });
    }

    // Deletes a weight entry by ID and updates the list
    public void deleteWeightEntry(int id) {
        executor.execute(() -> {
            dbHelper.deleteWeightEntry(id);
            loadEntries(); // Refresh list after deletion
        });
    }

    // Loads all entries from the database and posts them to the LiveData
    private void loadEntries() {
        List<WeightEntry> entries = new ArrayList<>();
        Cursor cursor = dbHelper.getAllWeightEntries();
        if (cursor != null) {
            while (cursor.moveToNext()) {
                int id = cursor.getInt(0);
                String date = cursor.getString(1);
                String weight = cursor.getString(2);
                entries.add(new WeightEntry(id, date, weight));
            }
            cursor.close();
        }
        weightEntries.postValue(entries); // Push data to observers
    }
}
