package com.example.kinealyweighttrackingapp;

import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.TableRow;
import android.widget.TextView;

import com.amplifyframework.datastore.generated.model.WeightEntry;

public class TableRowFactory {

    public static TableRow createRow(
            Context context,
            WeightEntry entry,
            WeightEntryViewModel viewModel
    ) {
        TableRow row = new TableRow(context);

        // Date Column (Temporal.Date → String)
        TextView dateText = new TextView(context);
        String dateString = entry.getDate() != null
                ? entry.getDate().toString()
                : "—";
        dateText.setText(dateString);
        dateText.setPadding(10, 10, 10, 10);
        dateText.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

        // Weight Column (e.g. BigDecimal → String)
        TextView weightText = new TextView(context);
        String weightString = entry.getWeight() != null
                ? entry.getWeight().toString()
                : "—";
        weightText.setText(weightString);
        weightText.setPadding(10, 10, 10, 10);
        weightText.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

        // Delete Button
        Button deleteButton = new Button(context);
        deleteButton.setText(R.string.delete);
        deleteButton.setOnClickListener(v ->
                viewModel.deleteWeightEntry(entry.getId())
        );

        // Add to row
        row.addView(dateText);
        row.addView(weightText);
        row.addView(deleteButton);

        return row;
    }
}
