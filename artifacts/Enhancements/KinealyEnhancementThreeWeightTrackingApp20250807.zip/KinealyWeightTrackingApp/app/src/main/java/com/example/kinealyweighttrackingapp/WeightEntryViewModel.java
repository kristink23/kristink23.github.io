package com.example.kinealyweighttrackingapp;

import android.app.Application;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.amplifyframework.core.Amplify;
import com.amplifyframework.api.graphql.model.ModelMutation;
import com.amplifyframework.api.graphql.model.ModelQuery;
import com.amplifyframework.core.model.query.Where;
import com.amplifyframework.core.model.temporal.Temporal;
import com.amplifyframework.datastore.generated.model.WeightEntry;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;

public class WeightEntryViewModel extends AndroidViewModel {
    private static final String TAG = "WVM";
    private final MutableLiveData<List<WeightEntry>> weightEntries = new MutableLiveData<>();
    private String currentUserId;

    public WeightEntryViewModel(@NonNull Application application) {
        super(application);
        getCurrentUserAndLoadEntries();
    }

    public LiveData<List<WeightEntry>> getWeightEntries() {
        return weightEntries;
    }

    private void getCurrentUserAndLoadEntries() {
        Amplify.Auth.getCurrentUser(
                user -> {
                    currentUserId = user.getUserId();
                    loadEntries();
                },
                error -> {
                    Log.e(TAG, "Failed to get current user: " + error);
                    // Fallback: load all entries (shouldn't happen if user is logged in)
                    loadEntries();
                }
        );
    }

    public void addWeightEntry(String dateStr, double weight, Consumer<Boolean> callback) {
        // validate date
        if (dateStr == null || dateStr.isEmpty()) {
            Log.e(TAG, "Invalid date: null or empty");
            if (callback != null) callback.accept(false);
            return;
        }
        // Validate weight
        if (Double.compare(weight, 0.0) <= 0) {
            Log.e(TAG, "Invalid weight: " + weight);
            if (callback != null) callback.accept(false);
            return;
        }

        // Get current user ID before creating entry
        if (currentUserId == null) {
            Amplify.Auth.getCurrentUser(
                    user -> {
                        currentUserId = user.getUserId();
                        createWeightEntry(dateStr, weight, callback);
                    },
                    error -> {
                        Log.e(TAG, "Failed to get user ID for new entry");
                        if (callback != null) callback.accept(false);
                    }
            );
        } else {
            createWeightEntry(dateStr, weight, callback);
        }
    }

    private void createWeightEntry(String dateStr, double weight, Consumer<Boolean> callback) {
        WeightEntry newEntry = WeightEntry.builder()
                .userId(currentUserId)  // First required field
                .date(new Temporal.Date(dateStr))  // Second required field
                .weight(weight)  // Third required field
                .build();

        Amplify.API.mutate(
                ModelMutation.create(newEntry),
                response -> {
                    loadEntries();
                    if (callback != null) callback.accept(true);
                },
                error -> {
                    Log.e(TAG, "add failed", error);
                    if (callback != null) callback.accept(false);
                }
        );
    }

    public void deleteWeightEntry(String entryId) {
        WeightEntry toDelete = WeightEntry.justId(entryId);

        Amplify.API.mutate(
                ModelMutation.delete(toDelete),
                response -> loadEntries(),
                error -> Log.e(TAG, "delete failed", error)
        );
    }

    private void loadEntries() {
        if (currentUserId == null) {
            Log.w(TAG, "No user ID available, cannot load entries");
            return;
        }

        // Query only entries for the current user
        Amplify.API.query(
                ModelQuery.list(WeightEntry.class, WeightEntry.USER_ID.eq(currentUserId)),
                response -> {
                    if (response.hasData()) {
                        List<WeightEntry> entries = new ArrayList<>();
                        for (WeightEntry entry : response.getData()) {
                            entries.add(entry);
                        }
                        Collections.sort(entries, Comparator.comparing(WeightEntry::getDate));
                        weightEntries.postValue(entries);
                    }
                },
                error -> Log.e(TAG, "Load failed: " + error, error)
        );
    }

    public String calculateWeightTrend() {
        List<WeightEntry> entries = weightEntries.getValue();
        if (entries == null || entries.size() < 2) {
            return "Not enough data to calculate trend.";
        }
        int n = entries.size();
        double[] x = new double[n];
        double[] y = new double[n];
        for (int i = 0; i < n; i++) {
            x[i] = i + 1;
            y[i] = entries.get(i).getWeight();
        }
        double xMean = 0, yMean = 0;
        for (int i = 0; i < n; i++) {
            xMean += x[i];
            yMean += y[i];
        }
        xMean /= n;
        yMean /= n;
        double num = 0, den = 0;
        for (int i = 0; i < n; i++) {
            num += (x[i] - xMean) * (y[i] - yMean);
            den += (x[i] - xMean) * (x[i] - xMean);
        }
        double slope = num / den;
        if (slope > 0) {
            return "You are gaining weight.";
        } else if (slope < 0) {
            return "You are losing weight.";
        } else {
            return "Your weight is stable.";
        }
    }
}