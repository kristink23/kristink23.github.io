package com.example.kinealyweighttrackingapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import com.amplifyframework.datastore.generated.model.WeightEntry;

// Adapter class to manage how weight entries are displayed in the RecyclerView
public class WeightEntryAdapter extends RecyclerView.Adapter<WeightEntryAdapter.EntryViewHolder> {

    private List<WeightEntry> entries; // List of weight entry objects
    private Context context; // Context needed to inflate layout
    private OnDeleteClickListener deleteClickListener; // Listener for delete button clicks

    // Interface for handling delete button clicks
    public interface OnDeleteClickListener {
        void onDeleteClick(WeightEntry entry);
    }

    // Constructor for the adapter
    public WeightEntryAdapter(Context context, List<WeightEntry> entries, OnDeleteClickListener listener) {
        this.context = context;
        this.entries = entries;
        this.deleteClickListener = listener;
    }

    // Called when RecyclerView needs a new ViewHolder
    @NonNull
    @Override
    public EntryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the layout for a single weight entry row
        View view = LayoutInflater.from(context).inflate(R.layout.item_weight_entry, parent, false);
        return new EntryViewHolder(view);
    }

    // Binds data to the ViewHolder at the given position
    @Override
    public void onBindViewHolder(@NonNull EntryViewHolder holder, int position) {
        WeightEntry entry = entries.get(position); // Get the entry at the current position

        // Format the date properly
        try {
            String dateString = entry.getDate().format(); // Gets "2025-08-07"
            LocalDate date = LocalDate.parse(dateString);
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM d, yyyy");
            String formattedDate = date.format(formatter); // "Aug 7, 2025"
            holder.dateText.setText(formattedDate);
        } catch (Exception e) {
            // Fallback to simple format if parsing fails
            holder.dateText.setText(entry.getDate().format());
        }

        // Format weight with units
        holder.weightText.setText(String.format("%.1f lbs", entry.getWeight()));

        // Set up the delete button to trigger the provided listener
        holder.deleteButton.setOnClickListener(v -> deleteClickListener.onDeleteClick(entry));
    }

    // Returns the total number of entries in the list
    @Override
    public int getItemCount() {
        return entries.size();
    }

    // Updates the list of entries and refreshes the RecyclerView
    public void updateEntries(List<WeightEntry> updatedEntries) {
        this.entries = updatedEntries;
        notifyDataSetChanged(); // Tell the RecyclerView to re-render
    }

    // ViewHolder class to hold references to the views for each item
    static class EntryViewHolder extends RecyclerView.ViewHolder {
        TextView dateText, weightText;
        Button deleteButton;

        // Constructor that links Java fields to XML elements
        EntryViewHolder(View itemView) {
            super(itemView);
            dateText = itemView.findViewById(R.id.dateText);
            weightText = itemView.findViewById(R.id.weightText);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }
}