package com.example.kinealyweighttrackingapp;

import android.app.Application;
import android.util.Log;

import com.amplifyframework.AmplifyException;
import com.amplifyframework.auth.cognito.AWSCognitoAuthPlugin;
import com.amplifyframework.api.aws.AWSApiPlugin;
import com.amplifyframework.core.Amplify;
import com.amplifyframework.datastore.AWSDataStorePlugin;
import com.amplifyframework.datastore.generated.model.AmplifyModelProvider;

public class MyApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();

        try {
            // Initialize Amplify plugins
            Amplify.addPlugin(new AWSDataStorePlugin(AmplifyModelProvider.getInstance()));
            Amplify.addPlugin(new AWSApiPlugin());
            Amplify.addPlugin(new com.amplifyframework.auth.cognito.AWSCognitoAuthPlugin());

            Amplify.configure(getApplicationContext());

            Log.i("MyApp", "Amplify initialized successfully");

            // Optional: Log auth session at startup
            Amplify.Auth.fetchAuthSession(
                    result -> Log.i("AuthQuickStart", result.toString()),
                    error -> Log.e("AuthQuickStart", error.toString())
            );

        } catch (AmplifyException error) {
            Log.e("MyApp", "Could not initialize Amplify", error);
            // Consider showing a user-friendly error message or fallback behavior
        }
    }
}