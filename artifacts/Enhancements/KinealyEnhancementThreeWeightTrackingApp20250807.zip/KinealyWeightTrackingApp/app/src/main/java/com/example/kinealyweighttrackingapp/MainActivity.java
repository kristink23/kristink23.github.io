package com.example.kinealyweighttrackingapp;

import android.Manifest;
import android.view.Menu;
import android.view.MenuItem;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Load SharedPreferences
        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        boolean isLoggedIn = prefs.getBoolean("isLoggedIn", false);
        boolean hasCheckedSMS = prefs.getBoolean("hasCheckedSMS", false);

        if (!isLoggedIn) {
            //  First-time users go to Login Screen
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
            finish();
            return;
        }

        if (!hasCheckedSMS) {
            //  If SMS permission has never been checked, go to SMS Permission Screen
            Intent intent = new Intent(this, SMSPermissionActivity.class);
            startActivity(intent);
            finish();
            return;
        }

        //  If already logged in and SMS checked, go to Weight Tracking Activity
        Intent intent = new Intent(this, WeightTrackingActivity.class);
        startActivity(intent);
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}