package com.amplifyframework.datastore.generated.model;

import com.amplifyframework.core.model.temporal.Temporal;
import com.amplifyframework.core.model.ModelIdentifier;

import java.util.List;
import java.util.UUID;
import java.util.Objects;

import androidx.core.util.ObjectsCompat;

import com.amplifyframework.core.model.Model;
import com.amplifyframework.core.model.annotations.Index;
import com.amplifyframework.core.model.annotations.ModelConfig;
import com.amplifyframework.core.model.annotations.ModelField;
import com.amplifyframework.core.model.query.predicate.QueryField;

import static com.amplifyframework.core.model.query.predicate.QueryField.field;

/** This is an auto generated class representing the WeightEntry type in your schema. */
@SuppressWarnings("all")
@ModelConfig(pluralName = "WeightEntries", type = Model.Type.USER, version = 1)
@Index(name = "byUserId", fields = {"userId"})
public final class WeightEntry implements Model {
  public static final QueryField ID = field("WeightEntry", "id");
  public static final QueryField USER_ID = field("WeightEntry", "userId");
  public static final QueryField DATE = field("WeightEntry", "date");
  public static final QueryField WEIGHT = field("WeightEntry", "weight");
  public static final QueryField NOTE = field("WeightEntry", "note");
  private final @ModelField(targetType="ID", isRequired = true) String id;
  private final @ModelField(targetType="String", isRequired = true) String userId;
  private final @ModelField(targetType="AWSDate", isRequired = true) Temporal.Date date;
  private final @ModelField(targetType="Float", isRequired = true) Double weight;
  private final @ModelField(targetType="String") String note;
  private @ModelField(targetType="AWSDateTime", isReadOnly = true) Temporal.DateTime createdAt;
  private @ModelField(targetType="AWSDateTime", isReadOnly = true) Temporal.DateTime updatedAt;
  /** @deprecated This API is internal to Amplify and should not be used. */
  @Deprecated
   public String resolveIdentifier() {
    return id;
  }
  
  public String getId() {
      return id;
  }
  
  public String getUserId() {
      return userId;
  }
  
  public Temporal.Date getDate() {
      return date;
  }
  
  public Double getWeight() {
      return weight;
  }
  
  public String getNote() {
      return note;
  }
  
  public Temporal.DateTime getCreatedAt() {
      return createdAt;
  }
  
  public Temporal.DateTime getUpdatedAt() {
      return updatedAt;
  }
  
  private WeightEntry(String id, String userId, Temporal.Date date, Double weight, String note) {
    this.id = id;
    this.userId = userId;
    this.date = date;
    this.weight = weight;
    this.note = note;
  }
  
  @Override
   public boolean equals(Object obj) {
      if (this == obj) {
        return true;
      } else if(obj == null || getClass() != obj.getClass()) {
        return false;
      } else {
      WeightEntry weightEntry = (WeightEntry) obj;
      return ObjectsCompat.equals(getId(), weightEntry.getId()) &&
              ObjectsCompat.equals(getUserId(), weightEntry.getUserId()) &&
              ObjectsCompat.equals(getDate(), weightEntry.getDate()) &&
              ObjectsCompat.equals(getWeight(), weightEntry.getWeight()) &&
              ObjectsCompat.equals(getNote(), weightEntry.getNote()) &&
              ObjectsCompat.equals(getCreatedAt(), weightEntry.getCreatedAt()) &&
              ObjectsCompat.equals(getUpdatedAt(), weightEntry.getUpdatedAt());
      }
  }
  
  @Override
   public int hashCode() {
    return new StringBuilder()
      .append(getId())
      .append(getUserId())
      .append(getDate())
      .append(getWeight())
      .append(getNote())
      .append(getCreatedAt())
      .append(getUpdatedAt())
      .toString()
      .hashCode();
  }
  
  @Override
   public String toString() {
    return new StringBuilder()
      .append("WeightEntry {")
      .append("id=" + String.valueOf(getId()) + ", ")
      .append("userId=" + String.valueOf(getUserId()) + ", ")
      .append("date=" + String.valueOf(getDate()) + ", ")
      .append("weight=" + String.valueOf(getWeight()) + ", ")
      .append("note=" + String.valueOf(getNote()) + ", ")
      .append("createdAt=" + String.valueOf(getCreatedAt()) + ", ")
      .append("updatedAt=" + String.valueOf(getUpdatedAt()))
      .append("}")
      .toString();
  }
  
  public static UserIdStep builder() {
      return new Builder();
  }
  
  /**
   * WARNING: This method should not be used to build an instance of this object for a CREATE mutation.
   * This is a convenience method to return an instance of the object with only its ID populated
   * to be used in the context of a parameter in a delete mutation or referencing a foreign key
   * in a relationship.
   * @param id the id of the existing item this instance will represent
   * @return an instance of this model with only ID populated
   */
  public static WeightEntry justId(String id) {
    return new WeightEntry(
      id,
      null,
      null,
      null,
      null
    );
  }
  
  public CopyOfBuilder copyOfBuilder() {
    return new CopyOfBuilder(id,
      userId,
      date,
      weight,
      note);
  }
  public interface UserIdStep {
    DateStep userId(String userId);
  }
  

  public interface DateStep {
    WeightStep date(Temporal.Date date);
  }
  

  public interface WeightStep {
    BuildStep weight(Double weight);
  }
  

  public interface BuildStep {
    WeightEntry build();
    BuildStep id(String id);
    BuildStep note(String note);
  }
  

  public static class Builder implements UserIdStep, DateStep, WeightStep, BuildStep {
    private String id;
    private String userId;
    private Temporal.Date date;
    private Double weight;
    private String note;
    public Builder() {
      
    }
    
    private Builder(String id, String userId, Temporal.Date date, Double weight, String note) {
      this.id = id;
      this.userId = userId;
      this.date = date;
      this.weight = weight;
      this.note = note;
    }
    
    @Override
     public WeightEntry build() {
        String id = this.id != null ? this.id : UUID.randomUUID().toString();
        
        return new WeightEntry(
          id,
          userId,
          date,
          weight,
          note);
    }
    
    @Override
     public DateStep userId(String userId) {
        Objects.requireNonNull(userId);
        this.userId = userId;
        return this;
    }
    
    @Override
     public WeightStep date(Temporal.Date date) {
        Objects.requireNonNull(date);
        this.date = date;
        return this;
    }
    
    @Override
     public BuildStep weight(Double weight) {
        Objects.requireNonNull(weight);
        this.weight = weight;
        return this;
    }
    
    @Override
     public BuildStep note(String note) {
        this.note = note;
        return this;
    }
    
    /**
     * @param id id
     * @return Current Builder instance, for fluent method chaining
     */
    public BuildStep id(String id) {
        this.id = id;
        return this;
    }
  }
  

  public final class CopyOfBuilder extends Builder {
    private CopyOfBuilder(String id, String userId, Temporal.Date date, Double weight, String note) {
      super(id, userId, date, weight, note);
      Objects.requireNonNull(userId);
      Objects.requireNonNull(date);
      Objects.requireNonNull(weight);
    }
    
    @Override
     public CopyOfBuilder userId(String userId) {
      return (CopyOfBuilder) super.userId(userId);
    }
    
    @Override
     public CopyOfBuilder date(Temporal.Date date) {
      return (CopyOfBuilder) super.date(date);
    }
    
    @Override
     public CopyOfBuilder weight(Double weight) {
      return (CopyOfBuilder) super.weight(weight);
    }
    
    @Override
     public CopyOfBuilder note(String note) {
      return (CopyOfBuilder) super.note(note);
    }
  }
  

  public static class WeightEntryIdentifier extends ModelIdentifier<WeightEntry> {
    private static final long serialVersionUID = 1L;
    public WeightEntryIdentifier(String id) {
      super(id);
    }
  }
  
}
