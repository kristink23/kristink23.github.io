package com.example.kinealyweighttrackingapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.amplifyframework.datastore.generated.model.WeightEntry;

import java.util.ArrayList;
import java.util.List;

public class WeightTrackingActivity extends AppCompatActivity {

    private WeightEntryViewModel viewModel;
    private WeightEntryAdapter adapter;

    private EditText dateInput;
    private EditText weightInput;
    private TextView trendText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_tracking);

        // Wire up the UI
        dateInput   = findViewById(R.id.dateInput);
        weightInput = findViewById(R.id.weightInput);
        Button addButton = findViewById(R.id.addButton);
        trendText   = findViewById(R.id.trendMessage);
        RecyclerView recyclerView = findViewById(R.id.recyclerView);

        // RecyclerView + Adapter
        viewModel = new ViewModelProvider(this)
                .get(WeightEntryViewModel.class);

        adapter = new WeightEntryAdapter(this, new ArrayList<>(), entry -> {
            viewModel.deleteWeightEntry(entry.getId());
        }
        );

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        viewModel.getWeightEntries().observe(this, entries -> {
            adapter.updateEntries(entries);
            String trend = viewModel.calculateWeightTrend();
            trendText.setText(trend);
        });

        // When "Add" is tapped:
        addButton.setOnClickListener(v -> {
            String dateStr = dateInput.getText().toString().trim();
            String weightStr = weightInput.getText().toString().trim();

            if (dateStr.isEmpty() || weightStr.isEmpty()) {
                Toast.makeText(this,
                        "Please enter both date and weight",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            double weightVal;
            try {
                weightVal = Double.parseDouble(weightStr);
            } catch (NumberFormatException e) {
                Toast.makeText(this,
                        "Invalid weight value",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            // Add the entry (three-arg signature with callback)
            viewModel.addWeightEntry(dateStr, weightVal, success -> {
                // Run UI updates on main thread
                runOnUiThread(() -> {
                    if (success) {
                        // Immediate feedback
                        Toast.makeText(this,
                                "Entry added!",
                                Toast.LENGTH_SHORT).show();

                        // Clear inputs
                        dateInput.setText("");
                        weightInput.setText("");
                    } else {
                        Toast.makeText(this,
                                "Failed to add entry",
                                Toast.LENGTH_SHORT).show();
                    }
                });
            });
        });
    }
}