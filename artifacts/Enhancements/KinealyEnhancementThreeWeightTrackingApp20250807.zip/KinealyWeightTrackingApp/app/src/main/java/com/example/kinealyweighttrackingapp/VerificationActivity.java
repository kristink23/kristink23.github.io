package com.example.kinealyweighttrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.amplifyframework.core.Amplify;

public class VerificationActivity extends AppCompatActivity {

    private EditText verificationCodeEditText;
    private TextView instructionText;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verification);

        verificationCodeEditText = findViewById(R.id.verificationCode);
        instructionText = findViewById(R.id.instructionText);

        // Get username from intent
        username = getIntent().getStringExtra("username");

        instructionText.setText("Please enter the verification code sent to " + username);
    }

    public void handleVerification(View view) {
        String verificationCode = verificationCodeEditText.getText().toString().trim();

        if (verificationCode.isEmpty()) {
            Toast.makeText(this, "Please enter verification code", Toast.LENGTH_SHORT).show();
            return;
        }

        Amplify.Auth.confirmSignUp(
                username,
                verificationCode,
                result -> runOnUiThread(() -> {
                    Toast.makeText(this, "Account verified! You can now log in.", Toast.LENGTH_LONG).show();
                    // Go back to login screen
                    Intent intent = new Intent(this, LoginActivity.class);
                    startActivity(intent);
                    finish();
                }),
                error -> runOnUiThread(() -> {
                    Toast.makeText(this, "Verification failed. Please try again.", Toast.LENGTH_LONG).show();
                })
        );
    }

    public void resendCode(View view) {
        Amplify.Auth.resendSignUpCode(
                username,
                result -> runOnUiThread(() ->
                        Toast.makeText(this, "Verification code resent!", Toast.LENGTH_SHORT).show()
                ),
                error -> runOnUiThread(() -> {
                    Toast.makeText(this, "Failed to resend code. Please try again.", Toast.LENGTH_SHORT).show();
                })
        );
    }
}