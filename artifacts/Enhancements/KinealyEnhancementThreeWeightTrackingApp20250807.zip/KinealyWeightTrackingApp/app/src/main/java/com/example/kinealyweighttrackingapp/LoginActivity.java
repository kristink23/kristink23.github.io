package com.example.kinealyweighttrackingapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.amplifyframework.core.Amplify;
import com.amplifyframework.auth.AuthException;
import com.amplifyframework.auth.AuthUserAttribute;
import com.amplifyframework.auth.AuthUserAttributeKey;
import com.amplifyframework.auth.options.AuthSignUpOptions;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameEditText, passwordEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        usernameEditText = findViewById(R.id.username);
        passwordEditText = findViewById(R.id.password);
    }

    public void handleLogin(View view) {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        Amplify.Auth.signIn(
                username,
                password,
                result -> {
                    if (result.isSignedIn()) {
                        runOnUiThread(() -> {
                            SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
                            prefs.edit().putBoolean("isLoggedIn", true).apply();
                            startActivity(new Intent(this, SMSPermissionActivity.class));
                            finish();
                        });
                    } else {
                        runOnUiThread(() ->
                                Toast.makeText(this, "Sign-in not complete", Toast.LENGTH_SHORT).show()
                        );
                    }
                },
                error -> runOnUiThread(() ->
                        Toast.makeText(this, "Login failed. If account not verified, use 'Verify Account' button.", Toast.LENGTH_LONG).show()
                )
        );
    }

    public void handleSignup(View view) {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Username and password cannot be empty.", Toast.LENGTH_SHORT).show();
            return;
        }

        AuthSignUpOptions options = AuthSignUpOptions.builder()
                .userAttribute(AuthUserAttributeKey.email(), username)
                .build();

        Amplify.Auth.signUp(
                username,
                password,
                options,
                result -> runOnUiThread(() -> {
                    Toast.makeText(this, "Signup successful! Check your email.", Toast.LENGTH_LONG).show();
                    // Navigate to verification screen
                    Intent intent = new Intent(this, VerificationActivity.class);
                    intent.putExtra("username", username);
                    startActivity(intent);
                }),
                error -> runOnUiThread(() ->
                        Toast.makeText(this, "Signup failed: " + error.getMessage(), Toast.LENGTH_SHORT).show()
                )
        );
    }

    public void handleResendVerification(View view) {
        String username = usernameEditText.getText().toString().trim();

        if (username.isEmpty()) {
            Toast.makeText(this, "Please enter your username/email first", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent intent = new Intent(this, VerificationActivity.class);
        intent.putExtra("username", username);
        startActivity(intent);
    }
}
